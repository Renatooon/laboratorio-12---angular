import { Component,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-navmenu',
  templateUrl: './navmenu.component.html',
  styleUrls: ['./navmenu.component.css'],
  encapsulation: ViewEncapsulation.None  // Deshabilita la encapsulación de estilos

})
export class NavmenuComponent {

}
