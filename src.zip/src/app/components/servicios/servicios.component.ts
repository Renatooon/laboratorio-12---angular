import { Component,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-servicios',
  templateUrl: './servicios.component.html',
  styleUrls: ['./servicios.component.css'],
  encapsulation: ViewEncapsulation.None  // Deshabilita la encapsulación de estilos

})
export class ServiciosComponent {

}
